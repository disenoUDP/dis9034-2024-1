// proyecto consiste en  salvapantallas con captura de video en vivo

let webcam;

//Se crea fondo en tono azul y se añade video en vivo via webcam como recurso
function setup() {
  createCanvas(800, 600, WEBGL);
  webcam = createCapture(VIDEO);
  webcam.hide();
}

//se dimensiona imagen de video dentro de un cubo que gira en ejes x, y, z

function draw() {
  // background(208, 220, 249);
  background(0, 51, 82);
  //image(webcam, 0, 0);
  webcam.size(130, 100);

  /*se añaden circulos en diferentes dimensiones en el fondo de manera aleatoria para que parezcan pequeños flashes. 
  en proceso !!! se quiere bajar la velocidad en la que aparecen sin modificar la velocidad de rotaciñon de los cubos. */
  //círculo pequeño blanco con aparición aleatoria en lienzo
  push();
  translate(random(width), random(height));
  fill(255, 255, 255);
  noStroke();
  circle(-450, -250, 5);
  pop();

  push();
  translate(random(width), random(height));
  fill(255, 255, 255);
  noStroke();
  circle(-450, -250, 5);
  pop();

  //círculo grande amarillo con aparición aleatoria en lienzo
  push();
  translate(random(width), random(height));
  fill(255, 255, 0);
  noStroke();
  circle(-450, -250, 10);
  pop();

  //círculo grande blanco con aparición aleatoria en lienzo
  push();
  translate(random(width), random(height));
  fill(255, 255, 255);
  noStroke();
  circle(-450, -250, 10);
  pop();

  //aparición de cubos con imagen en vivo
  //cubo grande, rotación variada
  rotateZ(frameCount * 0.03);
  rotateX(frameCount * 0.02);
  rotateY(frameCount * 0.01);
  texture(webcam);
  noStroke();
  box(220, 190, 220);

  //cubos pequeños, rotación variada
  /* 
  rotateZ(frameCount * 0.02);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.03);
  texture(webcam);
  noStroke();
  box(120, 90, 120); 
  */

  translate(200, 200);
  rotateZ(frameCount * 0.02);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.03);
  texture(webcam);
  noStroke();
  box(120, 90, 120);
}
