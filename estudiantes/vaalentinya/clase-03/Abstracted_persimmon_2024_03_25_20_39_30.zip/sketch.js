let cuadradito

function setup() {
  createCanvas(600, 600);
} 

function draw() {
  background(220);
  fill(0, 190, 130);
  cuadradito(200, 200, 200);
}

function girarConEstilo(cuadradito){
  fill(0, 190, 130)
  square(200, 200, 200)
  

}

// ayuda : ( 
